package net.lrivas.usorecyclerview;

public class ClaseAutos {
    private String nombre;
    private String informacion;
    private int foto;

    public ClaseAutos(){

    }

    public ClaseAutos(String nombre, String info, int foto){
        this.nombre = nombre;
        this.informacion = info;
        this.foto = foto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getInformacion() {
        return informacion;
    }

    public void setInformacion(String informacion) {
        this.informacion = informacion;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }
}
