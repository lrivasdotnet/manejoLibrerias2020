package net.lrivas.usorecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<ClaseAutos> listaAutos;
    RecyclerView recyclerAutos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        llenarRecycler();
    }

    private void llenarRecycler(){
        listaAutos = new ArrayList<>();
        recyclerAutos = findViewById(R.id.RecyclerId);
        recyclerAutos.setLayoutManager(new LinearLayoutManager(this));

        listaItemsAutos();
        AdaptadorAutos adapter = new AdaptadorAutos(listaAutos);
        recyclerAutos.setAdapter(adapter);
    }

    private void listaItemsAutos(){
        listaAutos.add(new ClaseAutos("RAV4 2020","Color Azul",R.drawable.car01));
        listaAutos.add(new ClaseAutos("Nissan Rogue 2020","Color Roja",R.drawable.car02));
        listaAutos.add(new ClaseAutos("Honda CRV 2020","Color Gris Rata",R.drawable.car03));
        listaAutos.add(new ClaseAutos("Ford Explorer 2020","Color Gris Rata",R.drawable.car04));
        listaAutos.add(new ClaseAutos("Mitsubishy Outlander 2020","Color Gris Rata",R.drawable.car05));
    }
}
