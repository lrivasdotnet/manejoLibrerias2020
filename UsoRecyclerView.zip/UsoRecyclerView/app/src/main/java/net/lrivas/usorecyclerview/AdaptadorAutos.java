package net.lrivas.usorecyclerview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdaptadorAutos extends RecyclerView.Adapter<AdaptadorAutos.ViewHolderAutos> implements View.OnClickListener {

    //Variables
    ArrayList<ClaseAutos> listaAutos;
    private View.OnClickListener listener;

    public AdaptadorAutos(ArrayList<ClaseAutos> lista){
        this.listaAutos = lista;
    }

    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;
    }


    @Override
    public void onClick(View view) {
        if(listener!=null){
            listener.onClick(view);
        }
    }

    @NonNull
    @Override
    public ViewHolderAutos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layout = R.layout.item_autos;
        View view = LayoutInflater.from(parent.getContext()).inflate(layout,null,false);
        view.setOnClickListener(this);
        return new ViewHolderAutos(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderAutos holder, int position) {
        holder.etiNombre.setText(listaAutos.get(position).getNombre());
        holder.etiInformacion.setText(listaAutos.get(position).getInformacion());
        holder.foto.setImageResource(listaAutos.get(position).getFoto());
    }

    @Override
    public int getItemCount() {
        return listaAutos.size();
    }

    public class ViewHolderAutos extends  RecyclerView.ViewHolder{
        TextView etiNombre, etiInformacion;
        ImageView foto;

        public ViewHolderAutos(View itemView){
            super(itemView);
            etiNombre = itemView.findViewById(R.id.idNombre);
            etiInformacion = itemView.findViewById(R.id.idInfo);
            foto = itemView.findViewById(R.id.idImagen);
        }
    }
}
